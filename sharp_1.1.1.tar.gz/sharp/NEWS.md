# sharp version 1.1.0

First release of stability selection methods and simulation models.
